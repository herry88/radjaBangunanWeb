<ul>
    <li><a href='?open=Laporan-Provinsi' title='Laporan Provinsi'>Laporan Data Provinsi</a>    
    <li><a href='?open=Laporan-Kategori' title='Laporan Kategori'>Laporan Data Kategori</a>    
    <li><a href='?open=Laporan-Barang' title='Laporan Barang'>Laporan Data Barang </a></li>
    <li><a href='?open=Laporan-Pelanggan' title='Laporan Pelanggan'>Laporan Data Pelanggan </a></li>
    <li><a href='?open=Laporan-Pemesanan-Periode' title='Laporan Pemesanan'>Laporan Pemesanan Masuk - Periode</a></li>
	<li><a href="?open=Laporan-Pemesanan-Lunas-Tanggal">Laporan Pemesanan Lunas - Tanggal </a></li>
	<li><a href="?open=Laporan-Pemesanan-Lunas-Periode">Laporan Pemesanan Lunas - Periode</a></li>
</ul>	

