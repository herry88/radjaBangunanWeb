<html>
<head>
<title></title>
    <meta charset="utf-8">
    <title>About Us</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

     <style type="text/css">
          p{
            text-indent:50px;
          }
      </style>
    <!-- Le styles  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet"/>
    <link href="assets/css/bootstrap-responsive.css" rel="stylesheet"/>
	<link href="assets/css/docs.css" rel="stylesheet"/>
	 
    <link href="style.css" rel="stylesheet"/>
	<link href="assets/js/google-code-prettify/prettify.css" rel="stylesheet"/>
	
	<!-- Less styles  
	<link rel="stylesheet/less" type="text/css" href="less/bootsshop.less">
	<script src="less.js" type="text/javascript"></script>
	 -->
	
    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="assets/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

</head>
<body>
<div class="span9" id="mainCol">
		<ul class="breadcrumb">
			<li><a href="?open=''">Home</a><span class="divider">/</span></li>
			<li class="active">Cara Pengembalian</li>
			<li>Corporate</li>
		</ul>
		<h3>Cara Pengembalian</h3>
		<hr class="soft">
			<h3><font color="red">Radja</font> <font color="green">Bangunan</font></h3><br/>
	
        <font face:'comic sans';>
<strong>Cara Menjadi Member</strong><br>
<p>
Jika ada barang yang tidak sesuai dengan yang Anda inginkan, maka Anda bisa melakukan prosedur pengembalian barang yang sesuai dengan persyaratan dari kami.
 Anda bisa langsung menghubungi admin ecommerce kami via sms atau whatsapp ke : 0812 1080 4080
</p>		
</div>
</div>
</body>
</html>