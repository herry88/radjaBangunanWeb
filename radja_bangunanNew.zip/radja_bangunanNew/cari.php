                <form action="?open=BarangPencarian" class="navbar-search pull-left">
                     <input name="txtKeyword" id="srchFld" type="text" size="30" placeholder="I'm looking for ..." class="search-query span5"/> <input type="submit" name="btnCari" value="Cari">
                    </form>