<?php
class Config
{
	// TODO: change with your actual server_key that can be found on Merchant Administration Portal (MAP)
	const SERVER_KEY = "VT-server-zl2uCIcsHIIbBVopZFNFN4D7";

	

	// TODO : change to production URL for your production Environment
	// sandbox/development/testing environment:
	const ENDPOINT = "https://api.sandbox.veritrans.co.id/v2/charge";
	// production environment:
	//const ENDPOINT = "https://api.sandbox.veritrans.co.id/v2/charge";
}
?>