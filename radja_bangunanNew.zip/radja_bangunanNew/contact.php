
	<hr class="soften">
	<div>
		<h1>Visit us</h1>
	</div>
	<hr class="soften"/>	
	<div class="row">
		<div class="span4">
		<h4>Contact Details</h4>
		<p>	<font color="red">Radja</font> <font color="green">Bangunan</font><br/> Jl. Jenderal Sudirman
			<br/><br/>
			Bekasi<br/>
			Kota Bekasi, Jawa Barat 13557<br/>
            +62 21 8861822<br />
			Indonesia<br/>
			web:www.radjabangunan.co.id
		</p>		
		</div>
			
		<div class="span4">
		<h4>Opening Hours</h4>
			<h5> Monday - Friday</h5>
			<p>08:00am - 05:00pm<br/><br/></p>
			<h5>Saturday</h5>
			<p>08:00am - 09:00pm<br/><br/></p>
			<br><br>
		</div>
<br><br><br><br>	

            <div class="span4">
	<iframe  width="790" height="250" frameborder="0" scrolling="no" marginheight="0" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3966.2345099489826!2d106.992008!3d-6.232786!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x1c81b202e00b1a7a!2sRadja+Bangunan!5e0!3m2!1sid!2sid!4v1432107355716" width="1170" height="220" frameborder="0" style="border:0"></iframe><br /><small><a href="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3966.2345099489826!2d106.992008!3d-6.232786!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x1c81b202e00b1a7a!2sRadja+Bangunan!5e0!3m2!1sid!2sid!4v1432107355716" style="color:#0000FF;text-align:left">View Larger Map</a></small>
	</div>
		</div>
	</div>

	
<!-- Footer ------------------------------------------------------ -->


