<!-- Footer ------------------------------------------------------ -->
<hr class="soft">
<div  id="footerSection">
	<div class="row">
		<div class="span3">
			<h5>Informasi</h6>
			<a href="?open=CaraMember"><font  color="Blue">Cara Jadi Member</font></a>
			<a href="?open=KeuntunganMember"><font color= "blue">Keuntungan Jadi Member</font></a> 
			<a href="?open=CaraBelanja"><font color="blue">Cara Belanja</font></a> 
			<a href="?open=CaraPengembalian"><font color="blue">Cara Pengembalian</font></a>  
			<a href="#"><font color="blue">Career</font></a>
		 </div>
		<div class="span3">
			<h5>Kontak</h5>
            <a href="?open=KontakKami"><font color="blue">Kontak Kami</font></a>    
			<a href="?open=TermQuestion"><font color="blue">Terms And Question</font></a> 
			<a href="#"><font color="blue">Faq</font></a>
		 </div>
		<div class="span3">
			<h5>Jelajahi RB</h5>
			<a href="?open=SyaratKetentuan"><font color="blue">Syarat & Ketentuan</font></a> 
			<a href="#"><font color="blue">Kebijakan Privasi</font></a>  
			
		 </div>
		<div id="socialMedia" class="span3 pull-right">
			<h5>SOCIAL MEDIA </h5>
			<a href="#"><img width="60" src="assets/img/facebook.png" title="facebook"/></a>
			<a href="#"><img width="60" src="assets/img/twitter.png" title="twitter"/></a>
			<a href="#"><img width="60" src="assets/img/rss.png" title="rss"/></a>
			<a href="#"><img width="60" src="assets/img/youtube.png" title="youtube"/></a>
		 </div> 
	 </div>
	 <hr class="soft">
	<p class="pull-left">&copy;2015 <font color= "red"><b>Radja</b></font> <font color="green"><b>Bangunan</b></font> <font color="grey"><b>Online Shop</b></font></p>
</div><!-- /container -->


    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
    <script src="assets/js/jquery.js"></script>
	<script src="assets/js/google-code-prettify/prettify.js"></script>
    <script src="assets/js/application.js"></script>
    <script src="assets/js/bootstrap-transition.js"></script>
    <script src="assets/js/bootstrap-modal.js"></script>
    <script src="assets/js/bootstrap-scrollspy.js"></script>
    <script src="assets/js/bootstrap-alert.js"></script>
    <script src="assets/js/bootstrap-dropdown.js"></script>
    <script src="assets/js/bootstrap-tab.js"></script>
    <script src="assets/js/bootstrap-tooltip.js"></script>
    <script src="assets/js/bootstrap-popover.js"></script>
    <script src="assets/js/bootstrap-button.js"></script>
    <script src="assets/js/bootstrap-collapse.js"></script>
    <script src="assets/js/bootstrap-carousel.js"></script>
    <script src="assets/js/bootstrap-typeahead.js"></script>
    <script src="assets/js/bootstrap-affix.js"></script>
    <script src="assets/js/jquery.lightbox-0.5.js"></script>
	<script src="assets/js/bootsshoptgl.js"></script>
	 <script type="text/javascript">
    $(function() {
        $('#gallery a').lightBox();
    });
    </script>
