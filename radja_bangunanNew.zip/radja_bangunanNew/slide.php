<!-- Start WOWSlider.com BODY section -->
<div id="wowslider-container1">
<div class="ws_images"><ul>
        <li><img src="data1/images/1.jpg" alt="" title="" id="wows1_0"/></li>
        <li><img src="data1/images/2.jpg" alt="" title="" id="wows1_1"/></li>
        <li><img src="data1/images/3.jpg" alt="" title="" id="wows1_2"/></li>
        <li><img src="data1/images/4.jpg" alt="multipro_general" title="" id="wows1_3"/></li>
        <li><a href="http://wowslider.com/vi"><img src="data1/images/5.jpg" alt="slider bootstrap" title="" id="wows1_4"/></a></li>
        <li><img src="data1/images/6.jpg" alt="wd_40" title="" id="wows1_5"/></li>
    </ul></div>
    <div class="ws_bullets"><div>
        <a href="#" title="alpine"><span><img src="data1/tooltips/7.jpg" alt="alpine"/>1</span></a>
        <a href="#" title=""><span><img src="data1/tooltips/8.jpg" alt="bitec_slide"/>2</span></a>
        <a href="#" title="mayaka_aircooler-01"><span><img src="data1/tooltips/mayaka_aircooler01.jpg" alt="mayaka_aircooler-01"/>3</span></a>
        <a href="#" title=""><span><img src="data1/tooltips/9.jpg" alt="multipro_general"/>4</span></a>
        <a href="#" title=""><span><img src="data1/tooltips/10.jpg" alt="multipro_welding"/>5</span></a>
         <a href="#" title=""><span><img src="data1/tooltips/11.jpg" alt="multipro_welding"/>5</span></a>
          <a href="#" title=""><span><img src="data1/tooltips/12.jpg" alt="multipro_welding"/>5</span></a>       
        <a href="#" title="wd_40"><span><img src="data1/tooltips/wd_40.jpg" alt="wd_40"/>6</span></a>
    </div></div><div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.com">jquery image slider</a> by herry prasetyo</div>
<div class="ws_shadow"></div>
</div>  
<script type="text/javascript" src="engine1/wowslider.js"></script>
<script type="text/javascript" src="engine1/script.js"></script>
<!-- End WOWSlider.com BODY section -->